/* Nadav Horowitz 6/9/2023 Linkedlist.java
 * This file includes implementation for a traditional LinkedList object.
 * Class is compatible with generics
 * Methods implemented include add(), contains(), printList(), intersect(), and union().
 */
import java.util.*;
public class Linkedlist<Item> implements Iterable<Item>{

    public Node<Item> first;

    public Linkedlist(){}

    //Add to head of list
    public void add(Item item){
        Node<Item> oldfirst = first;
        first = new Node<>();
        first.item = item;
        first.next = oldfirst;
    }

    //Query if list contains an item
    public boolean contains(Item item){
        Node<Item> pointer = first;
        while(pointer != null){
            if(pointer.item == item){
                return true;
            }
            pointer = pointer.next;
        }
        return false;
    }


    //Utility method for printing and returning String representation of list
    public ArrayList<String> printList(){
        ArrayList<String> List = new ArrayList<>();
        Node<Item> pointer = first;
        while(pointer != null){
            List.add(pointer.item.toString());
            pointer = pointer.next;
        }
        System.out.println(List);
        System.out.println();
        return List;
    }


    //Method assembles and returns a set intersect list of this list, & given list
    public Linkedlist<Item> intersect(Linkedlist<Item> other){
        Linkedlist<Item> intersectList = new Linkedlist<>();
        Node<Item> pointer = this.first;

        while(pointer != null){
            if(other.contains(pointer.item)){
                intersectList.add(pointer.item);
            }
            pointer = pointer.next;
        }
        return intersectList;
    }


    //Method assembles and returns a set union list of this list, & given list
    public Linkedlist<Item> union(Linkedlist<Item> other){
        Linkedlist<Item> unionList = new Linkedlist<>();

        Node<Item> thisPointer = this.first;
        while(thisPointer != null){
            if(!unionList.contains(thisPointer.item)){
                unionList.add(thisPointer.item);
            }
            thisPointer = thisPointer.next;
        }

        Node<Item> otherPointer = other.first;
        while(otherPointer != null){
            if(!unionList.contains(otherPointer.item)){
                unionList.add(otherPointer.item);
            }
            otherPointer = otherPointer.next;
        }
        return unionList;
    }


    //Method returns ListIterator
    public ListIterator iterator(){
        return new ListIterator(); 
    }


    //ListIterator class for implementing Linkedlist Iterator object
    private class ListIterator implements Iterator<Item>{
        public Node<Item> current = first;

        public boolean hasNext(){
            return current !=null;
        }

        public Item next(){
            Item item = current.item;
            current = current.next;
            return item;
        }
    }
}