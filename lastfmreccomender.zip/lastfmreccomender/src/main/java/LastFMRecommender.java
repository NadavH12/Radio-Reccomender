/* Nadav Horowitz 6/9/2023 LastReccomender.java
 * This file contains implementation for listFreinds(), listArtists(), listTop10(), and reccomendTop10() along with various helper methods.
 * The file reads radio listener data from 3 input files and outputs artist reccomendations to the console.
 */
import java.io.*;
import java.util.*;

public class LastFMRecommender {
    
    Linkedlist<User> userList;
    HashMap<Integer,String> artistNames; //<artistID, artistName>

    //Constructor LastFMReccomender() initializes userList and artistNames fields, calls appropriate methods for loading data
    public LastFMRecommender(){
        userList = new Linkedlist<>();
        artistNames = new HashMap<Integer,String>();
        loadArtistNames();
        loadUserList(); 
        loadPlaysList();
    }


    //loadArtistNames() loads artistNames<Integer, String> field from artist data found in input file "artists.dat"
    //Prints error message and exits for file not found.
    void loadArtistNames(){
        try{
            File artists = new File("artists.dat");
            Scanner fileScan = new Scanner(artists,"utf-8");
            fileScan.nextLine();//discard header
            while(fileScan.hasNextLine()){
                String inputLine = fileScan.nextLine();
                String[] artistData = inputLine.split("\t");
                Integer artistId = Integer.parseInt(artistData[0]);
                String artistName = artistData[1];
                artistNames.put(artistId, artistName);
            }
            fileScan.close();
        } catch(FileNotFoundException e){
            System.out.println("artists file not found.");
            System.exit(0);
        }
    }


    //loadUserList method loads userList field from user data found in input file "user_freinds.dat"
    //Also loads each user's freindsList field
    //Prints error message and exits for file not found.
    void loadUserList(){
        try{
            File users = new File("user_friends.dat");
            Scanner fileScan = new Scanner(users);
            fileScan.nextLine();//discard header

            int prevUserID = -1;
            User prevUser = null;
            while(fileScan.hasNextLine()){
                String inputLine = fileScan.nextLine();
                String[] userData = inputLine.split("\t");
                
                int nextUserID = Integer.parseInt(userData[0]);
                String nextFreindID = userData[1];

                if(prevUserID != nextUserID){

                    if(prevUser != null){
                        userList.add(prevUser);
                    }

                    User newUser = new User(nextUserID);
                    newUser.addToFreindsList(nextFreindID);
                    prevUserID = nextUserID;
                    prevUser = newUser;
                } else {
                    prevUser.addToFreindsList(nextFreindID);
                }
            }
            userList.add(prevUser);
            fileScan.close();
        } catch (FileNotFoundException e){
            System.out.println("user_friends file not found.");
            System.exit(0);
        }
    }

    
    //loadPlaysList() method loads playsList field of User objects from input file "user_artists.dat"
    //loads playsList data for each User in userList
    //Prints error message and exits for file not found.
    void loadPlaysList(){
        try{
            File playsFile = new File("user_artists.dat");
            Scanner fileScan = new Scanner(playsFile);
            fileScan.nextLine();//discard header

            User u = null;
            int prevUserID = -1;
            while(fileScan.hasNextLine()){
                String inputLine = fileScan.nextLine();
                String[] userData = inputLine.split("\t");

                int userID = Integer.parseInt(userData[0]);
                int artistID = Integer.parseInt(userData[1]);
                int plays = Integer.parseInt(userData[2]);

                if(userID != prevUserID){
                    u = getUser(userID);
                    prevUserID = userID;
                }
                u.addToPlaysList(new Plays(artistID,plays));
            }
            fileScan.close();
        } catch(FileNotFoundException e){
            System.out.println("user_artists file not found.");
            System.exit(0);
        }
    }
    

    //listFreinds() prints the list of freinds of the given user
    ArrayList<String> listFriends(int user){   
        User u = getUser(user);
        System.out.println("Freinds List:");
        return u.printFreindsList();
    }


    //commonFreinds() prints the user1’s friends in common with user2
    ArrayList<String> commonFriends(int user1, int user2){
        User u1 = getUser(user1);
        User u2 = getUser(user2);

        Linkedlist<String> user1List = u1.freindsList;
        Linkedlist<String> user2List = u2.freindsList;
        
        Linkedlist<String> intersect = user1List.intersect(user2List);

        return intersect.printList();        
    }


    //prints the list of artists listened by both users
    ArrayList<String> listArtists(int user1, int user2){
        User u1 = getUser(user1);
        User u2 = getUser(user2);

        Linkedlist<Plays> user1List = u1.playsList;
        Linkedlist<Plays> user2List = u2.playsList;
        
        Linkedlist<Plays> union = user1List.union(user2List);

        return printArtistNames(union);
    }


    //printArtistNames takes a Linkedlist of Plays objects as parameter.
    //Iterates the list and uses the artistID field of each Plays and the artistNames<Integer, String> field 
    //to find and print the artist's names
    ArrayList<String> printArtistNames(Linkedlist<Plays> union){
        ArrayList<String> commonArtists = new ArrayList<>();
        Node<Plays> pointer = union.first;
        while(pointer != null){
            int artistID = pointer.item.artistID;
            String artistName = artistNames.get(artistID);
            commonArtists.add(artistName);
            pointer = pointer.next;
        }
        System.out.println("Common Artists:");
        System.out.println(commonArtists);
        System.out.println();
        return commonArtists;
    }


    //listTop10() takes a Linkedlist of User objects as parameter and prints the top10 most played artists of all the User objects.
    //The method iterates the playsList of each user in userList and stores the data for each artist in a map.
    //The method then prints the artists with the highest 10 plays from the map.
    String[] listTop10(Linkedlist<User> userList){
        TreeMap<Integer, Integer> artistPlaysMap = new TreeMap<>();

        Node<User> userListPointer = userList.first;
        while(userListPointer != null){

            Node<Plays> playsListPointer = userListPointer.item.playsList.first;
            while(playsListPointer != null){
                int id = playsListPointer.item.artistID;
                int plays = playsListPointer.item.weight;

                if(artistPlaysMap.get(id) != null){
                    plays += artistPlaysMap.get(id);
                } 

                artistPlaysMap.put(id, plays);
                playsListPointer = playsListPointer.next;
            }

            userListPointer = userListPointer.next;
        }
        return printAndReturnTop10(artistPlaysMap);
    }


    //prints the list of top 10 most popular artists listened by all users
    //Calls listTop10(Linkedlist<User> userlist) passing the list of all the users   
    String[] listTop10(){
        return listTop10(this.userList);  
    }

    
    //recommends 10 most popular artists listened by the given user and his/her friends.
    //The method gets a copy of the given user's freindsList. 
    //The method then assembles a Linkedlist<User> containg the user and their freinds.
    //The method then calls listTop10(), passing it the assembeled User list. 
    String[] recommend10(int user){
        User u = getUser(user);
        Linkedlist<String> userFreindsIDList = u.getFreindsListCopy();
        userFreindsIDList.add("" + user);
        
        Linkedlist<User> userAndFreindsList = new Linkedlist<>();
        Node<String> userIDPointer = userFreindsIDList.first;

        while(userIDPointer != null){
            int userID = Integer.parseInt(userIDPointer.item);
            User currentUser = getUser(userID);
            userAndFreindsList.add(currentUser);
            userIDPointer = userIDPointer.next;
        }
        return listTop10(userAndFreindsList);
    }


    //getUser() returns the User object matching the given userID
    //Iterates the userList to find and return specified user, otherwise returns null
    User getUser(int userID){
        Iterator<User> iter = userList.iterator();
        while(iter.hasNext()){
            User nextUser = iter.next();
            if(userID == nextUser.userID)
                return nextUser;
        }
        return null;
    }


    //printAndReturnTop10() takes a TreeMap<Integer,Integer> as parameter,
    //extracts the 10 highest values, formats and adds into String[], prints and returns.
    String[] printAndReturnTop10(TreeMap<Integer,Integer> artistPlays){
        String[] top10 = new String[10];

        for(int i = 0; i < 10; i++){
            int maxValue = 0;
            int maxKey = 0;

            for(Integer key : artistPlays.keySet()){
                int value = artistPlays.get(key);
                if(value > maxValue){
                    maxKey = key;
                    maxValue = value;
                }
            }

            String artistName = artistNames.get(maxKey);
            String top10Entry = artistName + "=" + maxValue;
            artistPlays.remove(maxKey);
            top10[i] = top10Entry;
        }
        System.out.println("Top 10:");
        System.out.println(Arrays.toString(top10));
        System.out.println();
        return top10;
    }      
}