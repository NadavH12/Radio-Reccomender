/* Nadav Horowitz 6/9/2023 Node.java
 * This file includes implementation details for a Node class used in Linkedlists. 
 */
public class Node<Item> {
    public Item item;
    public Node<Item> next;
}