/* Nadav Horowitz 6/9/2023 User.java
 * This file includes implementation details for a User object.
 * Each User object has a userID, and a freindsList & playsList as fields
 * File includes various utility methods like getFreindsListCopy(), addToPlaysList(), addToFreindsList(), etc.
 */
import java.util.*;
public class User {

    int userID;
    Linkedlist<String> freindsList;
    Linkedlist<Plays> playsList;
    

    //Constructor
    public User(int userID){
        this.userID = userID;
        freindsList = new Linkedlist<>();
        playsList = new Linkedlist<>();
    }

    //Method assembles and returns deep copy of freindsList field
    Linkedlist<String> getFreindsListCopy(){
        Linkedlist<String> freindsListCopy = new Linkedlist<>();
        
        Node<String> firstPointer = this.freindsList.first;
        while(firstPointer != null){
            freindsListCopy.add(firstPointer.item);
            firstPointer = firstPointer.next;
        }
        return freindsListCopy;
   }

   //Utility method used to add a freind to User's freindsList
    void addToFreindsList(String freindID){
        freindsList.add(freindID);
    }

    //Utility method used to print a User's freindsList
    ArrayList<String> printFreindsList(){
        return freindsList.printList();
    }

    //Utility method used to add a Play to User's playsList
    void addToPlaysList(Plays play){
        playsList.add(play);
    }   

    //toString() method returns String representation of userID
    public String toString(){
        return ("" + userID);
    }
}