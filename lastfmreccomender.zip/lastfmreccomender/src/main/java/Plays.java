/* Nadav Horowitz 6/9/2023 Plays.java
 * This file includes implementation details for a Plays object with an artistID field and a weight field
 */
public class Plays {

    int artistID;
    int weight;

    //Constructor, initializes fields
    public Plays(int artistID, int weight){
        this.artistID = artistID;
        this.weight = weight;
    }

    //compareTo method implemented so that 2 Plays objects can be compared to determine if they represent plays of the same artist
    int compareTo(Plays other){
        if(this.artistID == other.artistID)
            return 0;
        else
            return 1;
    }

    //toString method prints artistID
    public String toString(){
        return ("" + artistID);
    }   
}