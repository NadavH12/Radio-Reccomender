/* Nadav Horowitz 6/9/2023 LastFMRecommenderTest.java
 * This file includes Junit test methods for listFreinds(), listArtists(), listTop10(), and reccomend10().
 */
import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;

public class LastFMRecommenderTest {

    private LastFMRecommender FM;

    @Before
    public void setUp() {
        FM = new LastFMRecommender();
    }

    @Test
    //test the list of freinds of the lowest userID (userID = 2)
    public void testListFreinds1() {
        ArrayList<String> freindsList = FM.listFriends(2);
        ArrayList<String> testList = new ArrayList<>();        
        testList.add("1869");
        testList.add("1625");
        testList.add("1585");
        testList.add("1327");
        testList.add("1230");
        testList.add("1210");
        testList.add("1209");
        testList.add("909");
        testList.add("831");
        testList.add("761");
        testList.add("515");
        testList.add("428");
        testList.add("275");
        boolean test = testList.equals(freindsList);
        assertTrue(test);
    }

    @Test
    //test the list of freinds of an intermediate userID (userID = 500)
    public void testListFreinds2() {
        ArrayList<String> freindsList = FM.listFriends(500);
        ArrayList<String> testList = new ArrayList<>();
        testList.add("1975");
        testList.add("1888");
        testList.add("1801");
        testList.add("1204");
        testList.add("782");
        testList.add("440");
        boolean test = testList.equals(freindsList);
        assertTrue(test);
    }

    @Test
    //test the list of freinds of the highest userID (userID = 2100)
    public void testListFreinds3() {
        ArrayList<String> freindsList = FM.listFriends(2100);
        ArrayList<String> testList = new ArrayList<>();
        testList.add("607");
        testList.add("586");
        boolean test = testList.equals(freindsList);
        assertTrue(test);
    }

    @Test
    //test the list of artists of the highest userID and the lowest userID (2 & 2100)
    public void testListArtists1() {
        ArrayList<String> artistList = FM.listArtists(2,2100);

        String expected = "[Carpathian Forest, Moonspell, Behemoth, Gorgoroth, Emperor, Eluveitie, Slayer, Yann Tiersen, Tenhi, Agalloch, Marduk, Immortal, Cannibal Corpse, Deathspell Omega, Vader, Blut aus Nord, Dark Funeral, Rotting Christ, ColdWorld, Burzum, Alcest, Drudkh, Summoning, Lifelover, Nokturnal Mortum, Dominia, Amžius, Obtest, Nahash, Satanic Warmaster, Altorių Šešėliai, Luctus, Anubi, Dissimulation, Skepticism, Argharus, Shape of Despair, The Kilimanjaro Darkjazz Ensemble, novemthree, Peste Noire, Moëvöt, Celestia, Vilkduja, Les Discrets, Mortifera, Nyktalgia, Atsakau  niekadA, Domantas Razauskas, Atalyja, Les Chants de Nihil, Duran Duran, Morcheeba, Air, Hooverphonic, Kylie Minogue, Daft Punk, Thievery Corporation, Goldfrapp, New Order, Matt Bianco, Talk Talk, Prefab Sprout, Enigma, Röyksopp, Coldplay, Faithless, Madonna, Icehouse, Sade, Moby, Dido, Depeche Mode, Café Del Mar, Basia, Camouflage, Electronic, George Michael, The Adventures, Fiction Factory, Groove Armada, Portishead, Marc Almond, Cock Robin, Cut Copy, Spandau Ballet, Katie Melua, Deacon Blue, Gorillaz, Lady Gaga, Kosheen, Nik Kershaw, Vitamin Z, Jean-Michel Jarre, Ministry of Sound, Simply Red, Fleetwood Mac, Duffy, Japan, INXS, ABC]";
        String actual = artistList.toString();

        boolean test = expected.equals(actual);
        assertTrue(test);
    }

    @Test
    //test the list of artists of the lowest userID and an intermediate userID (2 & 501)
    public void testListArtists2() {
        ArrayList<String> artistList = FM.listArtists(2,501);

        String expected = "[Kylie Minogue, Madonna, Lady Gaga, James Blunt, Mariah Carey, Ana Carolina, Rihanna, Britney Spears, Jordin Sparks, Kelly Clarkson, Christina Aguilera, Leona Lewis, Beyoncé, Jennifer Lopez, Alicia Keys, P!nk, Katharine McPhee, Hilary Duff, Jonas Brothers, Ashley Tisdale, Avril Lavigne, The Pussycat Dolls, 宇多田ヒカル, 浜崎あゆみ, Evanescence, Miley Cyrus, Lindsay Lohan, Gwen Stefani, RBD, Demi Lovato, Shakira, Mandy Moore, t.A.T.u., Fresno, McFly, Pink, Joss Stone, Marjorie Estiano, BoA, 倖田來未, Spice Girls, High School Musical, Sara Bareilles, James Morrison, 安室奈美恵, Sandy e Junior, Rouge, Elis Regina, Jorge Vercilo, Edward Cullen, Duran Duran, Morcheeba, Air, Hooverphonic, Kylie Minogue, Daft Punk, Thievery Corporation, Goldfrapp, New Order, Matt Bianco, Talk Talk, Prefab Sprout, Enigma, Röyksopp, Coldplay, Faithless, Madonna, Icehouse, Sade, Moby, Dido, Depeche Mode, Café Del Mar, Basia, Camouflage, Electronic, George Michael, The Adventures, Fiction Factory, Groove Armada, Portishead, Marc Almond, Cock Robin, Cut Copy, Spandau Ballet, Katie Melua, Deacon Blue, Gorillaz, Lady Gaga, Kosheen, Nik Kershaw, Vitamin Z, Jean-Michel Jarre, Ministry of Sound, Simply Red, Fleetwood Mac, Duffy, Japan, INXS, ABC]";
        String actual = artistList.toString();

        boolean test = expected.equals(actual);
        assertTrue(test);
    }

    @Test
    //test the listTop10() method to find the most popular artists amongst all users
    public void testListTop10() {
        String[] expected = new String[]{"Britney Spears=2393140", "Depeche Mode=1301308", "Lady Gaga=1291387", "Christina Aguilera=1058405", "Paramore=963449", "Madonna=921198", "Rihanna=905423", "Shakira=688529", "The Beatles=662116", "Katy Perry=532545"};
        String[] actual = FM.listTop10();
        boolean test = Arrays.equals(expected,actual);
        assertTrue(test);
    }


    @Test
    //test the reccomendTop10() method to find the most popular artist amongst userID = 2 and userID = 2s freinds
    public void testReccomendTop10() {
        String[] expected = new String[]{"Duran Duran=207695", "Depeche Mode=42140", "Madonna=39505", "Panic! At the Disco=39369", "Rammstein=36956", "U2=26447", "The Cure=20776", "Pet Shop Boys=20596", "Simple Minds=14638", "Kylie Minogue=14089"};

        String[] actual = FM.recommend10(2);
        boolean test = Arrays.equals(expected,actual);
        assertTrue(test);
    }

    @After
    public void tearDown() {
        FM = null;
    }
}